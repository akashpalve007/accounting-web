<x-layouts.admin>
    <x-slot name="title">{{ trans('Employee Details') }}</x-slot>

    <x-slot name="content">
        <x-show.container>
            <x-show.content class="flex flex-col-reverse lg:flex-row mt-5 sm:mt-12 gap-y-4" override="class">
                <div class="container mx-auto p-4">
                    <h1>Employee Details</h1>
                    <!-- Content for Employee Details goes here -->
                    <p>Details of a specific employee will be displayed here.</p>
                </div>
            </x-show.content>
        </x-show.container>
    </x-slot>
</x-layouts.admin>
