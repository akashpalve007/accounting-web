<x-layouts.admin> 
    <x-slot name="title">{{ trans('Payroll') }}</x-slot>

    <x-slot name="favorite"
            title="Payroll"
            icon="credit_card"
            route="offline-payments.settings.edit"
    ></x-slot>

    <x-slot name="content">
        <x-show.container>
            <x-show.content class="flex flex-col-reverse lg:flex-row mt-5 sm:mt-12 gap-y-4" override="class">
            
            <div class="container mx-auto p-4">
                <div class="flex justify-between items-center mb-4">
                    <div class="relative">
                        <input type="text" id="searchInput" placeholder="Search or filter results.." class="px-4 py-2 border border-gray-300 rounded-full w-full pl-10 focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <svg class="w-5 h-5 text-gray-500 absolute left-3 top-1/2 transform -translate-y-1/2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-4.35-4.35m1.95-2.65a7 7 0 10-14 0 7 7 0 0014 0z" />
                        </svg>
                    </div>
                    <button style="background-color:#247bff;" id="newEmployeeBtn" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">New Employee</button>
                </div>
                <table class="min-w-full">
                    <thead class="border-b">
                        <tr>
                            <th class="p-3 text-left">
                                <input type="checkbox" class="form-checkbox">
                            </th>
                            <th class="p-3 text-left">Name</th>
                            <th class="p-3 text-left">Email</th>
                            <th class="p-3 text-left">Department</th>
                            <th class="p-3 text-left">Hire Date</th>
                        </tr>
                    </thead>
                    <tbody id="employeeTable">
                        <tr class="border-b">
                            <td class="p-3">
                                <input type="checkbox" class="form-checkbox">
                            </td>
                            <td class="p-3">Baran</td>
                            <td class="p-3">purine.marked0@icloud.com</td>
                            <td class="p-3">Graphic</td>
                            <td class="p-3">25 May 2022</td>
                        </tr>
                        <tr class="border-b">
                            <td class="p-3">
                                <input type="checkbox" class="form-checkbox">
                            </td>
                            <td class="p-3">Dilara</td>
                            <td class="p-3">purine.marked0@icloud.com</td>
                            <td class="p-3">Graphic</td>
                            <td class="p-3">25 May 2022</td>
                        </tr>
                        <tr class="border-b">
                            <td class="p-3">
                                <input type="checkbox" class="form-checkbox">
                            </td>
                            <td class="p-3">Eda</td>
                            <td class="p-3">purine.marked0@icloud.com</td>
                            <td class="p-3">Marketing</td>
                            <td class="p-3">25 May 2022</td>
                        </tr>
                    </tbody>
                </table>
                <p id="noResults" class="text-center text-gray-500 mt-4 hidden">No results found</p>
            </div>

            <!-- Modal -->
            <div id="newEmployeeModal" class="fixed inset-0 bg-gray-100 bg-opacity-50 flex items-center justify-center hidden">
                <div class="bg-white p-8 rounded shadow-lg w-2/5">
                    <h2 class="text-2xl font-bold mb-4">New Employee</h2>
                    <form>
                        <div class="grid grid-cols-2 gap-4">
                            <div class="mb-4">
                                <label class="block text-gray-700 text-sm font-bold mb-2" for="name">Name</label>
                                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" id="name" type="text" placeholder="Name">
                            </div>
                            <div class="mb-4">
                                <label class="block text-gray-700 text-sm font-bold mb-2" for="email">Email</label>
                                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" id="email" type="email" placeholder="Email">
                            </div>
                            <div class="mb-4">
                                <label class="block text-gray-700 text-sm font-bold mb-2" for="birthdate">Birth Date</label>
                                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" id="birthdate" type="date">
                            </div>
                            <div class="mb-4">
                                <label class="block text-gray-700 text-sm font-bold mb-2" for="gender">Gender</label>
                                <select class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" id="gender">
                                    <option>Male</option>
                                    <option>Female</option>
                                    <option>Other</option>
                                </select>
                            </div>
                            <div class="mb-4">
                                <label class="block text-gray-700 text-sm font-bold mb-2" for="phone">Phone</label>
                                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" id="phone" type="tel" placeholder="Phone">
                            </div>
                            <div class="mb-4">
                                <label class="block text-gray-700 text-sm font-bold mb-2" for="department">Department</label>
                                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" id="department" type="text" placeholder="Department">
                            </div>
                            <div class="col-span-2 mb-4">
                                <label class="block text-gray-700 text-sm font-bold mb-2" for="address">Address</label>
                                <textarea class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" id="address" placeholder="Address"></textarea>
                            </div>
                        </div>
                        <div class="flex justify-end">
                            <button type="button" id="cancelBtn" class="bg-gray-500 text-white px-4 py-2 rounded mr-2 hover:bg-gray-600">Cancel</button>
                            <button type="submit" style="background-color:#247bff;" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Save</button>
                        </div>
                    </form>
                </div>
            </div>

            <script>
                document.getElementById('newEmployeeBtn').addEventListener('click', function() {
                    document.getElementById('newEmployeeModal').classList.remove('hidden');
                });

                document.getElementById('cancelBtn').addEventListener('click', function() {
                    document.getElementById('newEmployeeModal').classList.add('hidden');
                });

                document.getElementById('searchInput').addEventListener('keyup', function() {
                    var filter = this.value.toLowerCase();
                    var rows = document.querySelectorAll('#employeeTable tr');
                    var noResults = document.getElementById('noResults');
                    var visibleRowCount = 0;

                    rows.forEach(function(row) {
                        var name = row.cells[1].textContent.toLowerCase();
                        var email = row.cells[2].textContent.toLowerCase();
                        var department = row.cells[3].textContent.toLowerCase();

                        if (name.includes(filter) || email.includes(filter) || department.includes(filter)) {
                            row.style.display = '';
                            visibleRowCount++;
                        } else {
                            row.style.display = 'none';
                        }
                    });

                    if (visibleRowCount === 0) {
                        noResults.classList.remove('hidden');
                    } else {
                        noResults.classList.add('hidden');
                    }
                });
            </script>


            </x-show.content>
        </x-show.container>
    </x-slot>


</x-layouts.admin>
