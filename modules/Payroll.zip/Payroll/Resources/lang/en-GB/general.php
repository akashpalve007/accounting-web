<?php

return [

    'name'              => 'Payroll',
    'description'       => 'This is my awesome module',

];