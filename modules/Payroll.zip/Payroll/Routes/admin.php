<?php

use Illuminate\Support\Facades\Route;

/**
 * 'admin' middleware and 'payroll' prefix applied to all routes (including names)
 *
 * @see \App\Providers\Route::register
 */

Route::admin('payroll', function () {
    Route::get('/', function () {
        return view("payroll::index");
    })->name("index");
   // Route::get('/', 'Main@index');
});

// Route::get('/employee-details', 'Main@employeeDetails')->name('payroll.employee_details');
// Route::get('/employees', 'Index@employeeDetails')->name('payroll.index');
// Route::get('/run-payroll', 'Index@payrollDetails')->('payroll.run_payroll');
